# ZEUS AI

Aplicativo web/PWA responsivo com ZEUS CHAT e ZEUS ART, pronto para deploy na Vercel.

## Configuração na Vercel
1. Importe este projeto/repositório na Vercel.
2. Em **Settings → Environment Variables**, crie `POLLINATIONS_API_KEY` com sua chave secreta `sk_` da Pollinations.
3. Marque Production (e Preview se desejar), salve e faça **Redeploy**.
4. Abra o domínio gerado pela Vercel no Android. No Chrome, menu ⋮ → **Adicionar à tela inicial**.

A chave nunca deve ser colocada nos arquivos do site, no GitHub ou em mensagens.

## Funcionalidades atuais
- ZEUS CHAT: conversa com modelo de texto da Pollinations.
- ZEUS ART: geração de imagens via Pollinations.
- Interface responsiva e instalável como PWA.

Vídeo, música e voz ainda não estão implementados nesta primeira versão. O uso depende do saldo, das permissões e da disponibilidade da conta Pollinations; não há promessa de uso gratuito ou ilimitado.
